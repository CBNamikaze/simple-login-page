import React from "react";

const Home = () => {
  return <div>Logged in Successfully!</div>;
};

export default Home;
